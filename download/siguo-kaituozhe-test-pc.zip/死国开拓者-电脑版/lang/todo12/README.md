# lang/todo12：0.14.2.3 同步后未翻的 1 行（已译完）

合并：`python3 tools/i18n/merge_csv.py lang/todo12`，再跑 `python3 tools/i18n/check_csv.py` 和 `node tools/i18n/build_lang.js en`。
