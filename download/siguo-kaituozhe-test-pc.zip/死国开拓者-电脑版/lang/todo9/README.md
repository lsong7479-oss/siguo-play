# lang/todo9：0.12.8 新增的未翻行（1391 行，已译完）

0.12.8 同步后 lang/en 未翻 4224 行：其中 2833 行就是 lang/todo8 里已经译好的（id、zh 都对得上），剩下的 1391 行（data 428、ui 963，没有剧情）放在这里，只填了 en 列。
校验：`python3 tools/i18n/check_csv.py lang/todo9` → 错误合计 0。

合并（两批都要合，先后无所谓，merge_csv 按 id + zh 对）：
```
python3 tools/i18n/merge_csv.py lang/todo8
python3 tools/i18n/merge_csv.py lang/todo9
python3 tools/i18n/check_csv.py
node tools/i18n/build_lang.js en
```
合完 lang/en 应当是 0 行未翻。

## 这一批新定的译名
- 龙神遗迹 Dragon God Ruins · 自然龙神•希娜 Xina, Nature Dragon God · 德拉贡一世 Dragan I · 圣焰龙珠 Holy Flame Dragon Pearl · 氪金战士 Pay-to-Win Warrior
- 英雄：希娜 Xina（龙之恩赐 Dragon's Gift …）· 联盟共主-亚瑟 Arthur, Sovereign of the Alliance（誓约 Oath：正义 Justice / 公平 Fairness / 守护 Protection）· 大贤者 Great Sage · 进阶-X Ascended X · 二次进阶 Second Ascension
- 幸存者模式 Survivor Mode · 娱乐模式 Fun Modes · 装置 Device · 宝箱 Chest · 队长 Captain · 精英小队 Elite Squad
- 死国（难度开关）Deadland · 绝境 Perdition · 隐士 Hermit · 仙法 Immortal Art（仙法试炼 Immortal Art Trial）
- 重点培养 Focused Training · 英才计划 Prodigy Program · 培养值 Training Points
