# lang/todo8：0.12.5e 未翻的 2860 行（已译完）

来源：lang/en/*.csv 里 en 为空的行（data 709、ui 1059、story 1092），原样抽出，只填了 en 列。
校验：`python3 tools/i18n/check_csv.py lang/todo8` → 错误合计 0。

合并：
```
python3 tools/i18n/merge_csv.py lang/todo8
python3 tools/i18n/check_csv.py
node tools/i18n/build_lang.js en
```

## 这一批新定的译名
- 阵营 / 地图：黑曜 Obsidian（黑曜要塞 Obsidian Fortress）· 北原 Steppe（守望长城 Great Wall Watch，北原可汗·伊尔斯 Ils, Steppe Khan）· 源能 Aether（源能王城 Aether Capital，议会元老·艾斯 Ais, Council Elder）· 边军 Border Army（边军大营 Border Army Camp）· 星阳 Starsun · 冥夜 Nether Night · 日轮 Sun Wheel
- 新英雄：永 Yong（日轮王子 Sun Wheel Prince）· 堇 Jin（冥夜公主 Nether Night Princess）· 胡寒 Hu Han（北境守将 Warden of the North）· 多伦 Doran（十二勇士 One of the Twelve）· 艾斯 Ais（议会元老 Council Elder）
- 机制：骇入 Hack · 电磁干扰 EM Jamming · 闪电装置 Lightning Device · 闪电射线 Lightning Beam · 将领 General · 特遣 Dispatch · 奇遇 Encounter · 索贡 Demand Tribute
- 剧情：X传 The Tale of X · 联盟（亚瑟的）the Alliance · 海洋联盟 the Ocean Alliance · 教廷 the Church · 比索斯家 the Bisos family · 开拓令 The Settlement Decree（正文 settlement decree）
- 「X 加入联盟：开放这里的精英招募、家族声望和婚配」统一为 "X joins the Alliance: Elite recruitment, Family Rep and Marriage are now open here"
