# lang/todo10：0.13 主线同步后新增的未翻行（3015 行，已译完）

11-10 同步后 lang/en 未翻 6779 行：其中 3764 行就是 lang/todo8、lang/todo9 里已经译好的（id、zh 对得上），剩下 3015 行（data 1213、ui 902、story 900）放在这里，只填了 en 列。
校验：`python3 tools/i18n/check_csv.py lang/todo10` → 错误合计 0。

合并（三批都要合，先后无所谓，merge_csv 按 id + zh 对）：
```
python3 tools/i18n/merge_csv.py lang/todo8
python3 tools/i18n/merge_csv.py lang/todo9
python3 tools/i18n/merge_csv.py lang/todo10
python3 tools/i18n/check_csv.py
node tools/i18n/build_lang.js en
```
合完 lang/en 应当是 0 行未翻。

## 这一批新定的译名
- 王都家族：奥马金 Omagin · 克略 Kleo · 霍利 Holly · 西奥 Theo · 劳伦斯 Lawrence · 罗伯特 Robert · 奥斯本 Osborne · 博蒙 Beaumont；新家族 安科 Anko · 拉格拉斯 Raglas · 洛特 Lott
- 新剧情：开拓前夕 The Eve of Settlement · 开拓令 the Settlement Decree · 御前会议 the Royal Council · 北伐 the Northern Expedition · 流民 refugees · 哨堡 / 石堡（荒野据点）the fort（初次出现 watch fort / stone fort）· 哨站（腐化之地）outpost · 里瓦 Riva · 汉斯老人家 Old Hans · 苦根草 bitterroot · 化尸散 corpse-melt
- 新英雄：李偃 Li Yan（傀儡师 Puppeteer）· 玛蒂 Mati · 帕恩 Payne（航空司令 Air Commander）· 米修斯 Mysius（妖火贤师 Witchfire Sage）· 狩魔 Slayer's（狩魔领主 Slayer Lord）
- 天灾海域 Scourge Sea · 搜打撤 Extraction · 保险口袋 Safe Pocket · 英灵碑 Heroes' Stele · 追猎印记 Pursuit Mark（猎魔标记 仍是 Hunter's Mark）
