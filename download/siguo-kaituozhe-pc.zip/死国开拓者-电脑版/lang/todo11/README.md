# lang/todo11：11-19 同步后未翻的剧情（2049 行，已译完）

lang/en/story.csv 里 en 为空的 2049 行：第 21 区引子「内阁会议」重写、第 21/22 区几句改句、第 23–36 区新剧情（冰原、荒漠、丛林、第一卷终章、第二卷第一至六章）。只填了 en 列。
校验：`python3 tools/i18n/check_csv.py lang/todo11` → 错误合计 0。

合并：
```
python3 tools/i18n/merge_csv.py lang/todo11
python3 tools/i18n/check_csv.py
node tools/i18n/build_lang.js en
```
合完 lang/en 应当是 0 行未翻。

## 这一批新定的译名
- 内阁 the Cabinet · 内阁会议 the Cabinet Meeting · 财政大臣 Lord Treasurer · 西奥公爵 Duke Theo · 克略公爵 Duke Kleo · 奥马金公爵 Duke Omagin · 霍利侯爵 Marquis Holly
- 冰原 the Icefield · 荒漠 the Desert Wastes · 丛林 the Jungle · 荒漠诸邦 the Desert States · 法里斯盟主 Lord Faris · 开拓者联盟 the Pioneers' Alliance（北境开拓者联盟 the Northern Pioneers' Alliance）· 盟主 Alliance leader
- 枭雄线 / 英雄线 (Warlord path) / (Hero path)；路线标记 "Desert route: Warlord" 这种写法 · 枭雄线结局 Warlord Ending
- 死气 death energy · 霍镖师 Master Huo · 亨利·威廉 Henry William · 亡灵统帅威廉 Undead Warlord William
- 「里」统一换算成英里（三十里 about ten miles、十里 three miles、百里 some thirty miles）
- 条件行（`route:枭雄`、`fav:罗兰>=3` 这种）也照样翻了：游戏只在显示时查表，逻辑仍用中文，不受影响
