# 第六批待翻译（65 句：data 13、ui 52）

2026-10-23：第五批已合进 `lang/en/`。这批是第五批交回之前中文又改过 / 新加的：雪夜神社怪组重配后的组名、开拓地界面重做（地区面板页签、供奉界面、政令卡片）等。

做法同前：只改本文件夹 `data.csv`、`ui.csv` 的 **en 列**（UTF-8 带 BOM，别改 id / zh，别增删行；空位 `{0}{1}` 每个原样出现一次）；先读 `tools/i18n/STYLE.md`、`tools/i18n/glossary.json`；翻完 `python3 tools/i18n/check_csv.py lang/todo6` 最后一行「错误合计 0」；中文提交信息提交。

主会话收到后：

    python3 tools/i18n/merge_csv.py lang/todo6
    python3 tools/i18n/check_csv.py
    node tools/i18n/build_lang.js en

合完删掉 `lang/todo6/`。
