# 待翻译（给翻译 Claude）

这一批（第二批）：v0.10.6 新加的句子——八阶新图废弃佛窟（罗汉像、僧人亡灵、四位尊者、腐化大愿佛陀、佛窟装备、新品质「上古」）、新英雄万法唯识·玄奘、新伤害类型「神圣」及相关说明（data 96 句、ui 77 句）。
名字参考：玄奘 Xuanzang（英雄全名「万法唯识·玄奘」）；尊者 = Venerable；罗汉 = Arhat；菩萨 = Bodhisattva；佛陀 = Buddha；袈裟 = Kasaya；上古 = Ancient（品质名，比 神话 Mythic 高一档）；神圣 = Holy（伤害类型）。

## 怎么做
1. `git pull` 拿到最新的 main。先读 `tools/i18n/STYLE.md`（翻译守则）和 `tools/i18n/glossary.json`（术语表）；以前定过的名字在 `lang/en/*.csv` 里，起新名字前先搜一下保持一致。
2. 只改本文件夹里的 `data.csv`、`ui.csv` 的 **en 列**（UTF-8 带 BOM；别改 id、zh 两列，别删行、别加行）。
   - 空位 `{0}` `{1}`……是代码拼进去的数字 / 名字，译文里每个都要原样出现一次（可以换顺序）。
   - 不是自然语言的（代码注释、单个符号）原样抄 zh。
3. 翻完跑 `python3 tools/i18n/check_csv.py lang/todo`，最后一行要是「错误合计 0」。
4. 提交到 main（中文提交信息，例如「翻译：v0.10.6 待翻译 233 句」）并推送。不要改别的文件。

## 主会话收到后
`python3 tools/i18n/merge_csv.py lang/todo` 合进 `lang/en/`，然后清空本文件夹。
